# Importing

from flask import Flask, render_template, request

# Interaction

web = Flask(__name__)

#Mapping

@web.route('/')
@web.route('/register')
# Inputs
def homepage():
    return  render_template('register.html')

@web.route("/confirmation" , methods = ['POST', 'GET'])
def register():
    if request.method == 'POST':
        n = request.form.get('name')
        c = request.form.get('city')
        p = request.form.get('phone')
        return render_template('confirm.html',name = n , city = c, phonenumber = p)
# Main

if __name__ == ' __main__':
    web.run(debug = True)

